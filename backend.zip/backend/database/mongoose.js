const mongoose = require("mongoose");

mongoose.promise = global.promise;

mongoose.connect('mongodb://127.0.0.1:27017/taskmanager', { userNewUrlParser: true, useUnifiedTopology: true })

    .then(() => console.log('Database connected '))
    .catch((error) => console.log(error));

module.exports = mongoose;
