import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-vaccine-distribution',
  templateUrl: './vaccine-distribution.component.html',
  styleUrls: ['./vaccine-distribution.component.scss']
})
export class VaccineDistributionComponent implements OnInit {

lists: List[]=[];
lists: Task[]=[];
listId: string;

  constructor(
    private distributionService: TaskService,
    private route: ActivatedRoute,
    private router: Router,
    ) { }

  ngOnInit(): void {
    this.distributionService.getLists()
  .subscribe((lists:List[]) => this.lists=lists);

  this.route.params.subscribe((params.params)=>{
    const listId = params.listId;
    If (!this.listId) return
    this.distributionService.getTasks(this.listId).subscibe((tasks: Task[])) => this.tasks = tasks);
  });
  }
  onTaskclick(task){
    this.distributionService.setcompleted(this.listId,task).subscribe(()=> task.completed = !Task.completed);
  }

}
