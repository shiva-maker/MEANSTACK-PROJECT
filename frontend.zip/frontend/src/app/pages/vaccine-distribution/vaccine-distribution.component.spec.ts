import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VaccineDistributionComponent } from './vaccine-distribution.component';

describe('VaccineDistributionComponent', () => {
  let component: VaccineDistributionComponent;
  let fixture: ComponentFixture<VaccineDistributionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VaccineDistributionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VaccineDistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
