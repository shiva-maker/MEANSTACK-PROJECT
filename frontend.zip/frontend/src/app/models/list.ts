export default class Lists{
  _id: string;
  title: string;

}
