import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VaccineDistributionComponent } from './pages/vaccine-distribution/vaccine-distribution.component';

const routes: Routes = [
  {path:'',component:VaccineDistributionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
